# TEAM DƯƠNG TRA CỨU — Starter
Bộ khung ban đầu gồm giao diện React, backend Express, API demo và Chrome Extension.

## Cần cài
- Node.js bản LTS: https://nodejs.org/
- VS Code (khuyên dùng): https://code.visualstudio.com/

## Chạy thử
1. Giải nén file ZIP.
2. Mở thư mục `team-duong-tra-cuu` bằng VS Code.
3. Mở Terminal trong VS Code.

Chạy backend:
```bash
cd server
npm install
cp .env.example .env
npm run dev
```
Windows PowerShell nếu `cp` không chạy: `Copy-Item .env.example .env`

Mở terminal thứ hai để chạy giao diện:
```bash
cd web
npm install
npm run dev
```
Mở địa chỉ được Vite hiển thị, thường là http://localhost:5173

## API demo
- `GET http://localhost:4000/api/v1/health`
- `GET http://localhost:4000/api/v1/tools`
- `GET http://localhost:4000/api/v1/demo/lookup?url=https%3A%2F%2Fexample.com`
Endpoint lookup yêu cầu header `x-api-key`, giá trị mặc định nằm trong `server/.env`. Hãy đổi key trước khi triển khai thật.

## Chrome Extension
Mở `chrome://extensions`, bật Developer mode, chọn Load unpacked và chọn thư mục `extension`.

Đây mới là bộ khung chạy thử, chưa phải dịch vụ sản xuất. Các tích hợp mạng xã hội thực tế cần được bổ sung riêng, ưu tiên API chính thức và dữ liệu công khai/được phép. Không nhập mật khẩu hoặc cookie mạng xã hội vào website.
